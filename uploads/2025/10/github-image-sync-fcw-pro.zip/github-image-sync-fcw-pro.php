<?php
/**
 * Plugin Name: Github Image Sync
 * Plugin URI:  https://example.com
 * Description: Github Image Sync Pro - Async with Action Scheduler (fallback), SVG support, rate limiting and concurrency control.
 * Version: 1.1.0
 * Author: facechangingworld
 * Text Domain: github-image-sync-fcw
 */

if (!defined('ABSPATH')) exit;

class FCW_GHIS_Pro {
    const OPT = 'fcw_ghis_pro_options';
    const LOG = 'fcw_ghis_pro_log';
    const QUEUE = 'fcw_ghis_pro_queue';
    const RATE = 'fcw_ghis_pro_rate';
    const DEFAULT_BATCH = 5;
    const DEFAULT_RATE_LIMIT = 50; // max GitHub API calls per minute by default

    public static function init() {
        add_action('admin_menu', array(__CLASS__,'admin_menu'));
        add_action('admin_init', array(__CLASS__,'register_settings'));
        add_action('add_attachment', array(__CLASS__,'enqueue_upload'));
        add_action('delete_attachment', array(__CLASS__,'enqueue_delete'));
        add_filter('wp_get_attachment_url', array(__CLASS__,'filter_attachment_url'),10,2);
        add_filter('wp_get_attachment_image_src', array(__CLASS__,'filter_attachment_image_src'),10,3);
        add_filter('upload_mimes', array(__CLASS__,'allow_svg_mime'));
        add_filter('wp_check_filetype_and_ext', array(__CLASS__,'svg_check_filetype'), 10, 4);

        // Use Action Scheduler if available
        if (function_exists('as_enqueue_async_action')) {
            // nothing to schedule here; will enqueue actions in AS
        } else {
            // fallback to wp-cron scheduled event every minute
            add_filter('cron_schedules', function($s){
                if(!isset($s['minutely'])) $s['minutely'] = array('interval'=>60,'display'=>'Every Minute');
                return $s;
            });
            add_action('fcw_ghis_process_queue_cron', array(__CLASS__,'process_queue_cron'));
            register_activation_hook(__FILE__, array(__CLASS__,'activation_cron'));
            register_deactivation_hook(__FILE__, array(__CLASS__,'deactivation_cron'));
        }

        // Admin AJAX
        add_action('wp_ajax_fcw_ghis_manual_sync', array(__CLASS__,'ajax_manual_sync'));
        add_action('wp_ajax_fcw_ghis_clear_logs', array(__CLASS__,'ajax_clear_logs'));

        // Expose plugin init
        add_action('init', array(__CLASS__,'maybe_init_as'));
    }

    public static function maybe_init_as(){
        // noop placeholder for future
    }

    // ---------- Activation/Deactivation for cron fallback
    public static function activation_cron(){
        if (!wp_next_scheduled('fcw_ghis_process_queue_cron')) {
            wp_schedule_event(time(), 'minutely', 'fcw_ghis_process_queue_cron');
        }
    }
    public static function deactivation_cron(){
        wp_clear_scheduled_hook('fcw_ghis_process_queue_cron');
    }

    public static function register_settings(){
        register_setting(self::OPT, self::OPT, array(__CLASS__,'validate_options'));
    }

    public static function admin_menu(){
        add_options_page('Github Image Sync','Github Image Sync','manage_options','fcw-ghis',array(__CLASS__,'settings_page'));
        add_submenu_page('options-general.php','GHIS Queue','GHIS Queue','manage_options','fcw-ghis-queue',array(__CLASS__,'queue_page'));
    }

    public static function settings_page(){
        if (!current_user_can('manage_options')) return;
        $opts = get_option(self::OPT, array());
        ?>
        <div class="wrap"><h1>Github Image Sync (Pro)</h1>
        <form method="post" action="options.php">
        <?php settings_fields(self::OPT); ?>
        <table class="form-table">
        <tr><th>Enable</th><td><input type="checkbox" name="<?php echo self::OPT;?>[enabled]" value="1" <?php checked(!empty($opts['enabled']),1);?> /></td></tr>
        <tr><th>GitHub Repo</th><td><input type="text" name="<?php echo self::OPT;?>[repo]" value="<?php echo esc_attr($opts['repo'] ?? '');?>" style="width:60%;" /><p class="description">Format owner/repo (eg: facechangingworld/image-bed)</p></td></tr>
        <tr><th>Branch</th><td><input type="text" name="<?php echo self::OPT;?>[branch]" value="<?php echo esc_attr($opts['branch'] ?? 'main');?>" /></td></tr>
        <tr><th>Upload Path</th><td><input type="text" name="<?php echo self::OPT;?>[path]" value="<?php echo esc_attr($opts['path'] ?? 'uploads');?>" /><p class="description">Path inside repo (no leading slash)</p></td></tr>
        <tr><th>CDN Domain</th><td><input type="text" name="<?php echo self::OPT;?>[domain]" value="<?php echo esc_attr($opts['domain'] ?? 'https://img.facechangingworld.com');?>" style="width:60%;" /></td></tr>
        <tr><th>Token</th><td><input type="password" name="<?php echo self::OPT;?>[token_raw]" value="" style="width:60%;" /><span style="color:#666;"><?php echo !empty($opts['token_stored']) ? '******** (saved)':'';?></span>
        <p class="description">Personal Access Token with repo permission. Leave empty to keep.</p></td></tr>
        <tr><th>Enable SVG</th><td><input type="checkbox" name="<?php echo self::OPT;?>[enable_svg]" value="1" <?php checked(!empty($opts['enable_svg']),1);?> /> Allow SVG upload and sync</td></tr>
        <tr><th>Auto Replace Frontend URLs</th><td><input type="checkbox" name="<?php echo self::OPT;?>[auto_replace]" value="1" <?php checked(!empty($opts['auto_replace']),1);?> /> Replace front-end URLs with CDN domain</td></tr>
        <tr><th>Batch Size</th><td><input type="number" min="1" max="20" name="<?php echo self::OPT;?>[batch_size]" value="<?php echo esc_attr($opts['batch_size'] ?? self::DEFAULT_BATCH);?>" /></td></tr>
        <tr><th>Rate Limit (per minute)</th><td><input type="number" min="10" max="500" name="<?php echo self::OPT;?>[rate_limit]" value="<?php echo esc_attr($opts['rate_limit'] ?? self::DEFAULT_RATE_LIMIT);?>" /><p class="description">Approximate max GitHub API calls per minute (plugin enforces basic rate limiting).</p></td></tr>
        <tr><th>Batch Resync</th><td><button class="button" id="fcw-ghis-resync">Start Batch Resync</button> <span id="fcw-ghis-resync-result"></span>
        <p class="description">This will queue all attachments for upload to GitHub.</p></td></tr>
        <tr><th>Logs</th><td><pre style="max-height:200px; overflow:auto; background:#f7f7f7; padding:10px;"><?php echo esc_html(get_option(self::LOG,'No logs yet'));?></pre>
        <button class="button" id="fcw-ghis-clear-logs">Clear Logs</button></td></tr>
        </table>
        <?php submit_button(); ?>
        </form>
        <script>
        (function(){
            document.getElementById('fcw-ghis-resync').addEventListener('click', function(e){
                e.preventDefault();
                if(!confirm('Queue all media attachments for resync to GitHub?')) return;
                var data = new FormData();
                data.append('action','fcw_ghis_manual_sync');
                data.append('nonce','<?php echo wp_create_nonce('fcw_ghis_manual');?>');
                fetch(ajaxurl, {method:'POST', credentials:'same-origin', body:data}).then(r=>r.json()).then(j=>{ document.getElementById('fcw-ghis-resync-result').innerText = j.message; });
            });
            document.getElementById('fcw-ghis-clear-logs').addEventListener('click', function(e){
                e.preventDefault();
                if(!confirm('Clear plugin logs?')) return;
                var data = new FormData();
                data.append('action','fcw_ghis_clear_logs');
                data.append('nonce','<?php echo wp_create_nonce('fcw_ghis_clear_logs');?>');
                fetch(ajaxurl, {method:'POST', credentials:'same-origin', body:data}).then(r=>r.json()).then(j=>{ location.reload(); });
            });
        })();
        </script>
        </div>
        <?php
    }

    public static function queue_page(){
        if (!current_user_can('manage_options')) return;
        $queue = get_option(self::QUEUE, array());
        ?>
        <div class="wrap"><h1>GHIS Queue</h1>
        <p>Pending jobs: <?php echo count($queue);?></p>
        <table class="widefat"><thead><tr><th>Type</th><th>Attachment</th><th>Attempts</th><th>Added</th></tr></thead><tbody>
        <?php foreach($queue as $job){
            echo '<tr><td>'.esc_html($job['type']).'</td><td>'.esc_html($job['attachment']).'</td><td>'.esc_html($job['attempts']).'</td><td>'.esc_html(date('Y-m-d H:i:s',$job['time'])).'</td></tr>';
        }?>
        </tbody></table>
        </div>
        <?php
    }

    public static function validate_options($input){
        $out = get_option(self::OPT, array());
        $out['enabled'] = !empty($input['enabled']) ? 1 : 0;
        if (!empty($input['token_raw'])) {
            $token = sanitize_text_field($input['token_raw']);
            $enc = self::encrypt_token($token);
            if ($enc) $out['token_stored'] = $enc;
        }
        $out['repo'] = sanitize_text_field($input['repo'] ?? $out['repo'] ?? '');
        $out['branch'] = sanitize_text_field($input['branch'] ?? $out['branch'] ?? 'main');
        $out['path'] = sanitize_text_field($input['path'] ?? $out['path'] ?? 'uploads');
        $out['domain'] = sanitize_text_field($input['domain'] ?? $out['domain'] ?? '');
        $out['enable_svg'] = !empty($input['enable_svg']) ? 1 : 0;
        $out['auto_replace'] = !empty($input['auto_replace']) ? 1 : 0;
        $out['batch_size'] = intval($input['batch_size'] ?? self::DEFAULT_BATCH);
        $out['rate_limit'] = intval($input['rate_limit'] ?? self::DEFAULT_RATE_LIMIT);
        return $out;
    }

    private static function encrypt_token($token){
        if (function_exists('openssl_encrypt') && defined('AUTH_KEY')) {
            $key = substr(hash('sha256', AUTH_KEY),0,32);
            $iv = openssl_random_pseudo_bytes(16);
            $enc = openssl_encrypt($token, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
            return base64_encode($iv.$enc);
        }
        return base64_encode($token);
    }
    private static function decrypt_token($enc){
        if (empty($enc)) return '';
        if (function_exists('openssl_decrypt') && defined('AUTH_KEY')) {
            $raw = base64_decode($enc);
            $iv = substr($raw,0,16);
            $data = substr($raw,16);
            $key = substr(hash('sha256', AUTH_KEY),0,32);
            $dec = openssl_decrypt($data, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv);
            if ($dec !== false) return $dec;
        }
        return base64_decode($enc);
    }

    public static function allow_svg_mime($m){
        $opts = get_option(self::OPT, array());
        if (!empty($opts['enable_svg'])) {
            $m['svg'] = 'image/svg+xml';
        }
        return $m;
    }

    public static function svg_check_filetype($data, $file, $filename, $mimes){
        $opts = get_option(self::OPT, array());
        if (!empty($opts['enable_svg']) && strtolower(pathinfo($filename, PATHINFO_EXTENSION)) === 'svg') {
            $ext = 'svg';
            $type = 'image/svg+xml';
            return array('ext'=>$ext,'type'=>$type,'proper_filename'=>$filename);
        }
        return $data;
    }

    // Enqueue functions (use Action Scheduler if available)
    public static function enqueue_upload($attachment_id){
        $opts = get_option(self::OPT, array());
        if (empty($opts['enabled'])) return;
        if (function_exists('as_enqueue_async_action')) {
            as_enqueue_async_action('fcw_ghis_as_upload', array('attachment'=>$attachment_id));
            self::log("Enqueued AS upload for $attachment_id");
        } else {
            $job = array('type'=>'upload','attachment'=>$attachment_id,'attempts'=>0,'time'=>time());
            self::push_queue($job);
            self::log("Enqueued cron upload for $attachment_id");
        }
    }

    public static function enqueue_delete($attachment_id){
        $opts = get_option(self::OPT, array());
        if (empty($opts['enabled'])) return;
        if (function_exists('as_enqueue_async_action')) {
            as_enqueue_async_action('fcw_ghis_as_delete', array('attachment'=>$attachment_id));
            self::log("Enqueued AS delete for $attachment_id");
        } else {
            $job = array('type'=>'delete','attachment'=>$attachment_id,'attempts'=>0,'time'=>time());
            self::push_queue($job);
            self::log("Enqueued cron delete for $attachment_id");
        }
    }

    // Queue push/pop helpers for cron fallback
    private static function push_queue($job){
        $queue = get_option(self::QUEUE, array());
        $queue[] = $job;
        update_option(self::QUEUE, $queue);
    }

    // Cron processor
    public static function process_queue_cron(){
        $opts = get_option(self::OPT, array());
        if (empty($opts['enabled'])) return;
        $batch = intval($opts['batch_size'] ?? self::DEFAULT_BATCH);
        $queue = get_option(self::QUEUE, array());
        if (empty($queue)) return;
        $processed = 0;
        $newq = $queue;
        while(!empty($newq) && $processed < $batch){
            $job = array_shift($newq);
            $processed++;
            $job['attempts'] = ($job['attempts'] ?? 0) + 1;
            $ok = false;
            if ($job['type'] === 'upload') $ok = self::process_upload_job($job['attachment']);
            else $ok = self::process_delete_job($job['attachment']);
            if (!$ok && $job['attempts'] < 4){
                $job['time'] = time();
                $newq[] = $job;
                self::log("Requeued job {$job['type']} for {$job['attachment']} attempts {$job['attempts']}");
            } elseif (!$ok){
                self::log("Job failed permanently {$job['type']} for {$job['attachment']}");
            }
        }
        update_option(self::QUEUE, $newq);
    }

    // AS handlers (if Action Scheduler present, register hooks)
    // Note: Action Scheduler will pass the args to function; we map to same processors
    public static function as_register_hooks(){
        if (!function_exists('as_enqueue_async_action')) return;
        add_action('fcw_ghis_as_upload', array(__CLASS__,'as_process_upload'));
        add_action('fcw_ghis_as_delete', array(__CLASS__,'as_process_delete'));
    }

    public static function as_process_upload($args){
        $attachment_id = $args['attachment'] ?? 0;
        return self::process_upload_job($attachment_id);
    }
    public static function as_process_delete($args){
        $attachment_id = $args['attachment'] ?? 0;
        return self::process_delete_job($attachment_id);
    }

    // Main upload/delete processors (shared by cron and AS)
    private static function process_upload_job($attachment_id){
        $opts = get_option(self::OPT, array());
        $token = !empty($opts['token_stored']) ? self::decrypt_token($opts['token_stored']) : '';
        if (empty($token) || empty($opts['repo'])) {
            self::log("Upload job missing token or repo");
            return false;
        }
        $file = get_attached_file($attachment_id);
        if (!$file || !file_exists($file)) {
            self::log("Upload job: file not found for $attachment_id");
            return true;
        }
        if (strtolower(pathinfo($file, PATHINFO_EXTENSION))==='svg' && !self::svg_is_safe($file)){
            self::log("SVG failed safety check: $file");
            return true;
        }
        $meta = wp_get_attachment_metadata($attachment_id);
        $files = array();
        $files[] = $file;
        if (!empty($meta['sizes']) && is_array($meta['sizes'])){
            foreach ($meta['sizes'] as $s){
                $path = path_join(pathinfo($file, PATHINFO_DIRNAME), $s['file']);
                if (file_exists($path)) $files[] = $path;
            }
        }
        foreach ($files as $f){
            $alt = preg_replace('/\.[^.]+$/', '.webp', $f);
            if ($alt && file_exists($alt)) $files[] = $alt;
        }
        // Rate limiting: ensure we don't exceed configured calls per minute
        $rate_limit = intval($opts['rate_limit'] ?? self::DEFAULT_RATE_LIMIT);
        foreach ($files as $f){
            if (!self::check_rate_limit($rate_limit)){
                // sleep a bit as fallback (cron will retry)
                self::log('Rate limit reached; pausing upload');
                return false;
            }
            $rel = self::relative_repo_path($f, $opts);
            $res = self::github_put_file($rel, $f, $token, $opts);
            self::increment_rate_count();
            if ($res && isset($res['content']['path'])){
                $uploaded[$f] = rtrim($opts['domain'],'/').'/'.ltrim($res['content']['path'],'/');
                self::log("Uploaded ".basename($f)." to ".$uploaded[$f]);
            } else {
                self::log("Failed upload ".basename($f));
                return false;
            }
        }
        if (!empty($uploaded)){
            update_post_meta($attachment_id, '_fcw_ghis_map', $uploaded);
            $first = reset($uploaded);
            update_post_meta($attachment_id, '_fcw_ghis_url', $first);
        }
        return true;
    }

    private static function process_delete_job($attachment_id){
        $opts = get_option(self::OPT, array());
        $token = !empty($opts['token_stored']) ? self::decrypt_token($opts['token_stored']) : '';
        if (empty($token) || empty($opts['repo'])) return false;
        $map = get_post_meta($attachment_id, '_fcw_ghis_map', true);
        if (empty($map) || !is_array($map)) {
            $file = get_attached_file($attachment_id);
            if (!$file) { self::log("Delete: no file"); return true; }
            $path = self::relative_repo_path($file, $opts);
            return self::github_delete_file($path, $token, $opts);
        }
        foreach ($map as $local=>$url){
            $parsed = wp_parse_url($url);
            if (!empty($parsed['path'])) $repo_path = ltrim($parsed['path'],'/');
            else $repo_path = ltrim(self::relative_repo_path($local,$opts),'/');
            // Rate limit check
            $rate_limit = intval($opts['rate_limit'] ?? self::DEFAULT_RATE_LIMIT);
            if (!self::check_rate_limit($rate_limit)){ self::log('Rate limit reached during delete'); return false; }
            self::github_delete_file($repo_path, $token, $opts);
            self::increment_rate_count();
        }
        delete_post_meta($attachment_id, '_fcw_ghis_map');
        delete_post_meta($attachment_id, '_fcw_ghis_url');
        return true;
    }

    // Helpers: relative repo path
    private static function relative_repo_path($local_file, $opts){
        $basedir = wp_upload_dir()['basedir'];
        $rel = str_replace(trailingslashit($basedir),'',$local_file);
        $path = trim($opts['path'],'/').'/'.str_replace('\\','/',$rel);
        return $path;
    }

    // GitHub API interactions
    private static function github_put_file($path, $local_file, $token, $opts){
        $content = file_get_contents($local_file);
        if ($content === false) return null;
        $b64 = base64_encode($content);
        $payload = array('message'=>'Upload '.basename($path),'content'=>$b64,'branch'=>$opts['branch']);
        $url = "https://api.github.com/repos/{$opts['repo']}/contents/".rawurlencode($path);
        $resp = self::github_api_request($url, $payload, $token, 'PUT');
        return $resp;
    }
    private static function github_delete_file($path, $token, $opts){
        $url = "https://api.github.com/repos/{$opts['repo']}/contents/".rawurlencode($path)."?ref=".rawurlencode($opts['branch']);
        $resp = self::github_api_request($url, null, $token, 'GET');
        if (isset($resp['sha'])) {
            $payload = array('message'=>'Delete '.basename($path),'sha'=>$resp['sha'],'branch'=>$opts['branch']);
            $delurl = "https://api.github.com/repos/{$opts['repo']}/contents/".rawurlencode($path);
            self::github_api_request($delurl, $payload, $token, 'DELETE');
            self::log("Deleted $path from GitHub");
            return true;
        } else {
            self::log("File not found on GitHub: $path");
            return true;
        }
    }
    private static function github_api_request($url, $data=null, $token='', $method='GET'){
        $args = array('headers'=>array('Authorization'=>'token '.$token,'User-Agent'=>'WP-GHIS-PRO','Accept'=>'application/vnd.github.v3+json'),'timeout'=>30);
        if ($data!==null) { $args['body']=json_encode($data); $args['headers']['Content-Type']='application/json'; }
        $resp = wp_remote_request($url, array_merge($args, array('method'=>$method)));
        if (is_wp_error($resp)) { self::log('HTTP error: '.$resp->get_error_message()); return null; }
        $body = wp_remote_retrieve_body($resp);
        return json_decode($body,true);
    }

    // Rate limiting: simple per-minute counter stored in option
    private static function check_rate_limit($limit){
        $now = time();
        $rate = get_option(self::RATE, array('ts'=>0,'count'=>0));
        if ($now - $rate['ts'] >= 60) {
            // reset
            $rate = array('ts'=>$now,'count'=>0);
            update_option(self::RATE, $rate);
        }
        if ($rate['count'] >= $limit) return false;
        return true;
    }
    private static function increment_rate_count(){
        $now = time();
        $rate = get_option(self::RATE, array('ts'=>0,'count'=>0));
        if ($now - $rate['ts'] >= 60) { $rate = array('ts'=>$now,'count'=>0); }
        $rate['count'] = ($rate['count'] ?? 0) + 1;
        update_option(self::RATE, $rate);
    }

    // Filters: replace frontend URL
    public static function filter_attachment_url($url, $post_id){
        if (is_admin()) return $url;
        $opts = get_option(self::OPT, array());
        if (empty($opts['auto_replace'])) return $url;
        $u = get_post_meta($post_id, '_fcw_ghis_url', true);
        if ($u) return esc_url($u);
        $map = get_post_meta($post_id, '_fcw_ghis_map', true);
        if (is_array($map) && !empty($map)) { $first = reset($map); return esc_url($first); }
        return $url;
    }
    public static function filter_attachment_image_src($image, $attachment_id, $size){
        if (is_admin()) return $image;
        $opts = get_option(self::OPT, array());
        if (empty($opts['auto_replace'])) return $image;
        $map = get_post_meta($attachment_id, '_fcw_ghis_map', true);
        if (is_array($map) && !empty($map)) {
            $meta = wp_get_attachment_metadata($attachment_id);
            if (!empty($meta['sizes'])) {
                foreach ($meta['sizes'] as $info) {
                    $local = path_join(pathinfo(get_attached_file($attachment_id), PATHINFO_DIRNAME), $info['file']);
                    if (isset($map[$local])) { $image[0]=esc_url($map[$local]); return $image; }
                }
            }
            $u = get_post_meta($attachment_id, '_fcw_ghis_url', true);
            if ($u) $image[0] = esc_url($u);
        }
        return $image;
    }

    // SVG basic sanitizer check (no scripts, no on* attributes)
    private static function svg_is_safe($file){
        $content = file_get_contents($file);
        if ($content === false) return false;
        if (preg_match('/<script\b/i',$content)) return false;
        if (preg_match('/on\w+\s*=/i',$content)) return false;
        return true;
    }

    // AJAX handlers
    public static function ajax_manual_sync(){
        if (!current_user_can('manage_options')) wp_send_json(array('success'=>false,'message'=>'no permission'));
        if (!wp_verify_nonce($_POST['nonce'],'fcw_ghis_manual')) wp_send_json(array('success'=>false,'message'=>'invalid'));
        $args = array('post_type'=>'attachment','posts_per_page'=>-1,'post_status'=>'inherit');
        $q = get_posts($args);
        $count = 0;
        foreach ($q as $a) {
            if (function_exists('as_enqueue_async_action')) {
                as_enqueue_async_action('fcw_ghis_as_upload', array('attachment'=>$a->ID));
            } else {
                $job = array('type'=>'upload','attachment'=>$a->ID,'attempts'=>0,'time'=>time());
                self::push_queue($job);
            }
            $count++;
        }
        wp_send_json(array('success'=>true,'message'=>"Queued $count attachments"));
    }
    public static function ajax_clear_logs(){
        if (!current_user_can('manage_options')) wp_send_json(array('success'=>false));
        if (!wp_verify_nonce($_POST['nonce'],'fcw_ghis_clear_logs')) wp_send_json(array('success'=>false));
        update_option(self::LOG,''); wp_send_json(array('success'=>true));
    }

    private static function log($msg){
        $old = get_option(self::LOG, '');
        $t = '['.date('Y-m-d H:i:s').'] '.$msg."\n";
        $new = $t.$old;
        update_option(self::LOG, substr($new,0,30000));
    }
}

// Register AS hooks if AS available
if (function_exists('as_enqueue_async_action')) {
    add_action('init', function(){ FCW_GHIS_Pro::as_register_hooks(); });
}

FCW_GHIS_Pro::init();
