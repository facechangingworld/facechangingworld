<?php
/*
Plugin Name: GitHub Image Sync Pro (Placeholder)
Version: 1.3
Description: Placeholder build. Real sync features coming next.
*/

add_action('admin_notices', function(){
    echo '<div class="notice notice-info"><p>GitHub Image Sync Pro placeholder installed. Full version will sync images to GitHub & replace URLs.</p></div>';
});
