GitHub Image Sync Pro v1.5-final
Keep local copy: YES
Map: image-bed/<year>/<month>/file.jpg
Branch: main
