GitHub Image Sync v2.0 - uploads mapping, keep local, subfolder compatible, branch main
