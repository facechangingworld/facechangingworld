# github-image-sync-fcw-pro

Github Image Sync Pro - Async queue with Action Scheduler (fallback), SVG safety, rate limiting, and concurrency control.

Features:
- Uses Action Scheduler if available; otherwise WP-Cron fallback
- Adjustable batch size and rate limit (admin settings)
- SVG upload support with basic sanitization check
- Asynchronous upload/delete for attachments; supports batch re-sync
- Stores mapping per attachment: _fcw_ghis_map and primary URL _fcw_ghis_url
- Admin Queue viewer and logs

Installation:
1. Upload and activate the plugin (Github Image Sync).
2. Configure repo, branch, path, domain, token in Settings > Github Image Sync.
3. Enable plugin and optionally SVG support.

Notes:
- For production, Action Scheduler is recommended. WooCommerce includes Action Scheduler.
- Rate limiting is a basic local counter; for heavy usage consider distributed rate control.
