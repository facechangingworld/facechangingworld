GitHub Image Sync Pro - Upgraded
Install: upload folder to /wp-content/plugins/ and activate. Then Settings -> GitHub Image Sync Pro
Features: upload to GitHub (uploads/...), WebP, CF purge, retry queue, editor replacement, batch replace, token masking.
