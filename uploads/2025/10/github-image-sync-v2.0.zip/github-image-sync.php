<?php
/*
Plugin Name: GitHub Image Sync
Description: Sync WP uploads to GitHub repository, map to /uploads/... (preserve local), upload sizes & webp, delete sync, Cloudflare purge, media status, batch sync, WP-CLI support.
Version: 2.0
Author: facechangingworld
*/

if (!defined('ABSPATH')) exit;

class GitHub_Image_Sync {
    private $opt = 'gis_opts_v2';
    private $queue_opt = 'gis_queue_v2';
    private $logs = 'gis_logs_v2';

    public function __construct() {
        add_action('admin_menu', [$this,'admin_menu']);
        add_action('admin_init', [$this,'admin_init']);
        add_action('add_attachment', [$this,'on_add_attachment']);
        add_action('delete_attachment', [$this,'on_delete_attachment']);
        add_action('wp_generate_attachment_metadata', [$this,'on_generate_metadata'], 10, 2);
        add_filter('wp_get_attachment_url', [$this,'filter_attachment_url'], 999, 2);
        add_filter('content_save_pre', [$this,'filter_content_save']);
        add_filter('attachment_fields_to_edit', [$this,'attachment_fields_to_edit'], 10, 2);
        add_filter('manage_media_columns', [$this,'media_columns']);
        add_action('manage_media_custom_column', [$this,'media_custom_column'], 10, 2);
        add_action('admin_post_gis_batch_sync', [$this,'handle_batch_sync']);
        if (!wp_next_scheduled('gis_retry_v2')) wp_schedule_event(time(), 'hourly', 'gis_retry_v2');
        add_action('gis_retry_v2', [$this,'process_queue']);
        if (defined('WP_CLI') && WP_CLI) {
            WP_CLI::add_command('github-sync migrate', [$this, 'wpcli_sync']);
        }
    }

    /* -------------------- Admin / Settings -------------------- */
    public function admin_menu() {
        add_menu_page('GitHub Image Sync','GitHub Image Sync','manage_options','github-image-sync',[$this,'settings_page']);
    }

    public function admin_init(){
        register_setting('gis_settings','gis_options');
        if (isset($_GET['gis_reset']) && $_GET['gis_reset']=='1' && current_user_can('manage_options')) {
            $o = get_option('gis_options', []); $o['token']=''; update_option('gis_options',$o);
            wp_redirect(admin_url('admin.php?page=github-image-sync')); exit;
        }
    }

    public function settings_page(){
        if (!current_user_can('manage_options')) return;
        $opts = $this->opts();
        if ($_POST && isset($_POST['gis_options'])) {
            check_admin_referer('gis_save');
            $data = $_POST['gis_options'];
            if (!empty($data['token']) && strpos($data['token'],'*')===false) $data['token'] = base64_encode(trim($data['token']));
            else $data['token'] = $opts['token'];
            update_option('gis_options',$data);
            $opts = $this->opts();
            echo '<div class="updated"><p>Saved.</p></div>';
        }
        $masked = !empty($opts['token']) ? str_repeat('*',12) : '';
        ?>
        <div class="wrap"><h1>GitHub Image Sync</h1>
        <form method="post" action="">
        <?php wp_nonce_field('gis_save'); $n='gis_options'; $o=$this->opts(); ?>
        <table class="form-table">
        <tr><th>GitHub Token</th><td>
            <input name="<?php echo $n; ?>[token]" value="<?php echo esc_attr($masked); ?>" <?php echo $masked? 'readonly':''; ?> size="60">
            <?php if ($masked): ?><a class="button" href="<?php echo esc_url(add_query_arg('gis_reset',1,admin_url('admin.php?page=github-image-sync'))); ?>">Reset Token</a><?php endif; ?>
            <p class="description">Use a fine-grained token limited to the repo (Contents: read & write). Token saved base64-encoded.</p>
        </td></tr>
        <tr><th>Repository</th><td><input name="<?php echo $n; ?>[repo]" value="<?php echo esc_attr($o['repo']); ?>" size="60"></td></tr>
        <tr><th>Branch</th><td><input name="<?php echo $n; ?>[branch]" value="<?php echo esc_attr($o['branch']); ?>" size="20"></td></tr>
        <tr><th>CDN Domain</th><td><input name="<?php echo $n; ?>[cdn]" value="<?php echo esc_attr($o['cdn']); ?>" size="60"></td></tr>
        <tr><th>Cloudflare Zone ID</th><td><input name="<?php echo $n; ?>[cf_zone]" value="<?php echo esc_attr($o['cf_zone']); ?>" size="60"></td></tr>
        <tr><th>Cloudflare API Token</th><td><input name="<?php echo $n; ?>[cf_token]" value="<?php echo esc_attr($o['cf_token']); ?>" size="60"></td></tr>
        <tr><th>Retry attempts</th><td><input name="<?php echo $n; ?>[retry]" value="<?php echo intval($o['retry']); ?>" size="4"></td></tr>
        </table>
        <?php submit_button(); ?>
        </form>

        <h2>Tools</h2>
        <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
            <?php wp_nonce_field('gis_batch'); ?>
            <input type="hidden" name="action" value="gis_batch_sync">
            <p><button class="button">Enqueue all uploads (bulk sync)</button></p>
        </form>

        <h2>Logs</h2>
        <?php $logs = get_option($this->logs,[]); if (!$logs) $logs=[]; ?>
        <table class="widefat"><thead><tr><th>Time</th><th>Type</th><th>Message</th></tr></thead><tbody>
        <?php foreach(array_slice(array_reverse($logs),0,200) as $l): ?>
            <tr><td><?php echo esc_html($l['time']); ?></td><td><?php echo esc_html($l['type']); ?></td><td><?php echo esc_html($l['msg']); ?></td></tr>
        <?php endforeach; ?>
        </tbody></table>

        </div>
        <?php
    }

    private function opts() {
        $def = [
            'token'=>'',
            'repo'=>'facechangingworld/image-bed',
            'branch'=>'main',
            'cdn'=>'https://img.facechangingworld.com',
            'cf_zone'=>'','cf_token'=>'','retry'=>3
        ];
        $o = get_option('gis_options',[]);
        return array_merge($def,is_array($o)?$o:[]);
    }

    private function get_token(){
        $o = $this->opts();
        if (empty($o['token'])) return false;
        $t = $o['token'];
        if (base64_decode($t,true)) return base64_decode($t);
        return $t;
    }

    /* -------------------- Mapping -------------------- */
    private function map_to_github($file){
        $up = wp_get_upload_dir();
        $basedir = $up['basedir'];
        $rel = ltrim(str_replace($basedir,'',$file),'/\\\\');
        $rel = str_replace('\\\\','/',$rel);
        return 'uploads/'.ltrim($rel,'/');
    }

    /* -------------------- Upload / Queue -------------------- */
    private function enqueue($path,$file){
        $q = get_option($this->queue_opt,[]);
        $q[]=['path'=>$path,'file'=>$file,'tries'=>0];
        update_option($this->queue_opt,$q);
    }

    public function on_add_attachment($post_id){
        $file = get_attached_file($post_id);
        if (!$file || !file_exists($file)) return;
        $this->upload_with_sizes($post_id,$file);
    }

    public function on_generate_metadata($metadata,$attachment_id){
        $file = get_attached_file($attachment_id);
        if ($file && file_exists($file)) $this->upload_with_sizes($attachment_id,$file);
        return $metadata;
    }

    private function upload_with_sizes($post_id,$file){
        $gpath = $this->map_to_github($file);
        if (!$this->github_put($gpath,$file)) $this->enqueue($gpath,$file); else $this->log('info',"Uploaded {$gpath}");
        $meta = wp_get_attachment_metadata($post_id);
        if (!empty($meta['sizes']) && is_array($meta['sizes'])){
            foreach($meta['sizes'] as $s){
                $sizefile = $this->size_path($file,$s);
                if (file_exists($sizefile)){
                    $srel = $this->map_to_github($sizefile);
                    if (!$this->github_put($srel,$sizefile)) $this->enqueue($srel,$sizefile);
                    else $this->log('info',"Uploaded {$srel}");
                }
            }
        }
        $webp = preg_replace('/\\.[^.]+$/','.webp',$file);
        if (file_exists($webp)){
            $wrel = $this->map_to_github($webp);
            if (!$this->github_put($wrel,$webp)) $this->enqueue($wrel,$webp);
            else $this->log('info',"Uploaded {$wrel}");
        }
        $opts = $this->opts();
        if (!empty($opts['cf_zone']) && !empty($opts['cf_token'])) {
            $cdn_url = rtrim($opts['cdn'],'/').'/'.$gpath;
            $this->purge_cloudflare($cdn_url);
        }
    }

    private function size_path($original,$size_meta){
        $pi = pathinfo($original);
        return $pi['dirname'].'/'.$pi['filename'].'-'.$size_meta['width'].'x'.$size_meta['height'].'.'.$pi['extension'];
    }

    /* -------------------- Delete sync -------------------- */
    public function on_delete_attachment($post_id){
        $file = get_attached_file($post_id);
        if (!$file) return;
        $gpath = $this->map_to_github($file);
        $this->github_delete($gpath);
        $meta = wp_get_attachment_metadata($post_id);
        if (!empty($meta['sizes']) && is_array($meta['sizes'])){
            foreach($meta['sizes'] as $s){
                $sf = $this->size_path($file,$s);
                $this->github_delete($this->map_to_github($sf));
            }
        }
        $this->github_delete($this->map_to_github(preg_replace('/\\.[^.]+$/','.webp',$file)));
        $this->log('info',"Deleted remote for {$gpath}");
    }

    /* -------------------- URL replacement -------------------- */
    public function filter_attachment_url($url,$post_id){
        $opts = $this->opts();
        $cdn = rtrim($opts['cdn'],'/');
        $file = get_attached_file($post_id);
        if (!$file) return $url;
        $rel = ltrim(str_replace(wp_get_upload_dir()['basedir'],'',$file),'/\\\\');
        $rel = str_replace('\\\\','/',$rel);
        return $cdn.'/uploads/'.ltrim($rel,'/');
    }

    public function filter_content_save($content){
        $opts = $this->opts();
        $cdn = rtrim($opts['cdn'],'/').'/uploads';
        $local = content_url('uploads');
        return str_replace($local,$cdn,$content);
    }

    /* -------------------- Media UI -------------------- */
    public function attachment_fields_to_edit($form_fields,$post){
        $url = wp_get_attachment_url($post->ID);
        $form_fields['cdn_link'] = ['label'=>'CDN Link','input'=>'html','html'=>'<input readonly style="width:100%" value="'.esc_attr($url).'">'];
        return $form_fields;
    }

    public function media_columns($cols){
        $cols['gis_sync'] = 'GitHub';
        return $cols;
    }

    public function media_custom_column($column,$id){
        if ($column!='gis_sync') return;
        $st = $this->check_remote($id);
        if ($st===true) echo '<span style="color:green">✅</span>';
        elseif ($st==='pending') echo '<span style="color:orange">⏳</span>';
        else echo '<span style="color:red">❌</span>';
    }

    private function check_remote($id){
        $file = get_attached_file($id);
        if (!$file) return false;
        $path = $this->map_to_github($file);
        if ($this->github_get($path)) return true;
        $q = get_option($this->queue_opt,[]);
        foreach($q as $it) if ($it['path']==$path) return 'pending';
        return false;
    }

    /* -------------------- Queue processing -------------------- */
    public function process_queue(){
        $q = get_option($this->queue_opt,[]);
        $opts = $this->opts();
        $new = [];
        foreach($q as $item){
            $ok = $this->github_put($item['path'],$item['file']);
            if ($ok) $this->log('info',"Retried {$item['path']}");
            else {
                $item['tries'] = $item['tries']+1;
                if ($item['tries'] < intval($opts['retry'])) $new[]=$item;
                else $this->log('error',"Give up {$item['path']}");
            }
        }
        update_option($this->queue_opt,$new);
    }

    /* -------------------- WP-CLI -------------------- */
    public function wpcli_sync($args,$assoc){
        WP_CLI::log('Enqueuing uploads...');
        $this->enqueue_all();
        WP_CLI::success('Enqueued.');
    }

    private function enqueue_all(){
        $up = wp_get_upload_dir();
        $base = $up['basedir'];
        $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($base));
        foreach($it as $f){
            if ($f->isFile()) {
                $rel = ltrim(str_replace($base,'',$f->getPathname()),'/\\\\');
                $this->enqueue('uploads/'.str_replace('\\\\','/',$rel), $f->getPathname());
            }
        }
        $this->log('info','Enqueued all uploads');
    }

    /* -------------------- GitHub API -------------------- */
    private function github_get($path){
        $opts = $this->opts(); $token = $this->get_token(); if (!$token) return false;
        $url = "https://api.github.com/repos/{$opts['repo']}/contents/".rawurlencode($path)."?ref=".rawurlencode($opts['branch']);
        $ch = curl_init();
        curl_setopt_array($ch,[CURLOPT_URL=>$url,CURLOPT_RETURNTRANSFER=>true,CURLOPT_HTTPHEADER=>["Authorization: token $token","User-Agent: GitHubImageSync"],CURLOPT_TIMEOUT=>20]);
        $res = curl_exec($ch); $code = curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch);
        if ($code==200) return json_decode($res,true); return false;
    }

    private function github_put($path,$localfile){
        $opts = $this->opts(); $token = $this->get_token(); if (!$token) { $this->log('error','No token'); return false; }
        $api = "https://api.github.com/repos/{$opts['repo']}/contents/".rawurlencode($path);
        $content = base64_encode(file_get_contents($localfile));
        $data = ['message'=>'Upload via GitHub Image Sync','content'=>$content,'branch'=>$opts['branch']];
        $exists = $this->github_get($path);
        if ($exists && isset($exists['sha'])) $data['sha'] = $exists['sha'];
        $ch = curl_init();
        curl_setopt_array($ch,[CURLOPT_URL'=>$api,CURLOPT_RETURNTRANSFER=>true,CURLOPT_CUSTOMREQUEST=>'PUT',CURLOPT_POSTFIELDS=>json_encode($data),CURLOPT_HTTPHEADER=>["Authorization: token $token","User-Agent: GitHubImageSync","Content-Type: application/json"],CURLOPT_TIMEOUT=>60]);
        $res = curl_exec($ch); $code = curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch);
        return ($code==201||$code==200);
    }

    private function github_delete($path){
        $opts = $this->opts(); $token = $this->get_token(); if (!$token) return false;
        $file = $this->github_get($path); if (!$file || empty($file['sha'])) return false;
        $api = "https://api.github.com/repos/{$opts['repo']}/contents/".rawurlencode($path);
        $data = ['message'=>'Delete via GitHub Image Sync','sha'=>$file['sha'],'branch'=>$opts['branch']];
        $ch = curl_init();
        curl_setopt_array($ch,[CURLOPT_URL'=>$api,CURLOPT_RETURNTRANSFER=>true,CURLOPT_CUSTOMREQUEST=>'DELETE',CURLOPT_POSTFIELDS=>json_encode($data),CURLOPT_HTTPHEADER=>["Authorization: token $token","User-Agent: GitHubImageSync","Content-Type: application/json"],CURLOPT_TIMEOUT=>30]);
        curl_exec($ch); curl_close($ch); return true;
    }

    private function purge_cloudflare($file_url){
        $opts = $this->opts();
        if (empty($opts['cf_zone']) || empty($opts['cf_token'])) return false;
        $api = 'https://api.cloudflare.com/client/v4/zones/'.trim($opts['cf_zone']).'/purge_cache';
        $body = json_encode(['files'=>[$file_url]]);
        $res = wp_remote_post($api,['headers'=>['Authorization'=>'Bearer '.trim($opts['cf_token']),'Content-Type'=>'application/json'],'body'=>$body,'timeout'=>15]);
        $this->log('info','CF purge requested for '.$file_url);
        return $res;
    }

    private function get_token(){ $o = $this->opts(); if (empty($o['token'])) return false; $t = $o['token']; if (base64_decode($t,true)) return base64_decode($t); return $t; }
    private function opts(){ $o = get_option('gis_options',[]); return wp_parse_args($o,['repo'=>'facechangingworld/image-bed','branch'=>'main','cdn'=>'https://img.facechangingworld.com','cf_zone'=>'','cf_token'=>'','retry'=>3]); }

    private function log($type,$msg){ $l = get_option($this->logs,[]); $l[]=['time'=>current_time('mysql'),'type'=>$type,'msg'=>$msg]; if(count($l)>1000)$l=array_slice($l,-1000); update_option($this->logs,$l); }
}

$GLOBALS['github_image_sync'] = new GitHub_Image_Sync();

add_action('admin_post_gis_batch_sync', function(){ $g=$GLOBALS['github_image_sync']; $g->enqueue_all(); wp_redirect(admin_url('admin.php?page=github-image-sync')); exit; });
add_action('admin_init', function(){ if (isset($_GET['gis_reset']) && $_GET['gis_reset']=='1' && current_user_can('manage_options')){ $o = get_option('gis_options',[]); $o['token']=''; update_option('gis_options',$o); wp_redirect(admin_url('admin.php?page=github-image-sync')); exit; } });
?>
