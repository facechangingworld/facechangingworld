<?php
/*
Plugin Name: GitHub Image Sync Pro v1.5-final
Description: Sync WP uploads -> facechangingworld/image-bed (preserve local), upload sizes & webp, delete sync, media library status & actions, bulk sync, branch main.
Version: 1.5-final
Author: FCW
*/

if (!defined('ABSPATH')) exit;

class GISPro_v15_Final {
    private $opt = 'gispro_v15_final_opts';
    private $queue = 'gispro_v15_final_queue';
    private $logs = 'gispro_v15_final_logs';

    public function __construct(){
        add_action('admin_menu', [$this,'admin_menu']);
        add_action('admin_init', [$this,'admin_init']);
        add_action('add_attachment', [$this,'on_add_attachment']);
        add_action('delete_attachment', [$this,'on_delete_attachment']);
        add_action('wp_generate_attachment_metadata', [$this,'on_generate_metadata'], 10, 2);
        add_filter('wp_get_attachment_url', [$this,'filter_attachment_url'], 999, 2);
        add_filter('attachment_fields_to_edit', [$this,'attachment_fields_to_edit'], 10, 2);
        add_filter('manage_media_columns', [$this,'media_columns']);
        add_action('manage_media_custom_column', [$this,'media_custom_column'], 10, 2);
        add_action('admin_post_gis_v15_final_action', [$this,'handle_admin_action']);
        if (!wp_next_scheduled('gispro_v15_final_retry')) wp_schedule_event(time(), 'hourly', 'gispro_v15_final_retry');
        add_action('gispro_v15_final_retry', [$this,'process_queue']);
        if (defined('WP_CLI') && WP_CLI) WP_CLI::add_command('gispro sync', [$this,'wpcli_sync']);
    }

    public function admin_menu(){
        add_menu_page('GitHub Image Sync','GitHub Image Sync','manage_options','gispro_v15_final',[$this,'settings_page']);
    }

    public function admin_init(){
        register_setting('gispro_v15_final','gispro_token');
        register_setting('gispro_v15_final','gispro_repo');
        register_setting('gispro_v15_final','gispro_branch');
        register_setting('gispro_v15_final','gispro_cdn');
        register_setting('gispro_v15_final','gispro_cf_zone');
        register_setting('gispro_v15_final','gispro_cf_token');
        register_setting('gispro_v15_final','gispro_retry');
    }

    public function settings_page(){
        if (!current_user_can('manage_options')) return;
        if ($_POST && isset($_POST['gispro_repo'])) {
            if (!empty($_POST['gispro_token']) && strpos($_POST['gispro_token'],'*')===false) {
                update_option('gispro_token', base64_encode(trim($_POST['gispro_token'])));
            }
            update_option('gispro_repo', sanitize_text_field($_POST['gispro_repo']));
            update_option('gispro_branch', 'main'); // locked to main per configuration
            update_option('gispro_cdn', esc_url_raw($_POST['gispro_cdn']));
            update_option('gispro_cf_zone', sanitize_text_field($_POST['gispro_cf_zone']));
            update_option('gispro_cf_token', sanitize_text_field($_POST['gispro_cf_token']));
            update_option('gispro_retry', intval($_POST['gispro_retry']));
            echo '<div class="updated"><p>Saved.</p></div>';
        }
        $token = get_option('gispro_token','');
        $masked = $token ? '**************' : '';
        $repo = get_option('gispro_repo','facechangingworld/image-bed');
        $branch = 'main';
        $cdn = get_option('gispro_cdn','https://img.facechangingworld.com');
        $cf_zone = get_option('gispro_cf_zone','');
        $cf_token = get_option('gispro_cf_token','');
        $retry = get_option('gispro_retry',3);
        ?>
        <div class="wrap"><h1>GitHub Image Sync Pro v1.5-final</h1>
        <form method="post" action="">
        <table class="form-table">
        <tr><th>GitHub Token</th><td>
            <input type="text" name="gispro_token" value="<?php echo esc_attr($masked); ?>" <?php echo $masked ? 'readonly' : ''; ?> size="60">
            <?php if ($masked): ?><a class="button" href="<?php echo esc_url(add_query_arg('reset',1,admin_url('admin.php?page=gispro_v15_final'))); ?>">Reset Token</a><?php endif; ?>
            <p>Token stored base64-encoded. To change, click Reset Token then save new token.</p>
        </td></tr>
        <tr><th>Repo</th><td><input type="text" name="gispro_repo" value="<?php echo esc_attr($repo); ?>" size="60"></td></tr>
        <tr><th>Branch</th><td><input type="text" readonly value="main" size="20"></td></tr>
        <tr><th>CDN</th><td><input type="text" name="gispro_cdn" value="<?php echo esc_attr($cdn); ?>" size="60"></td></tr>
        <tr><th>Cloudflare Zone ID</th><td><input type="text" name="gispro_cf_zone" value="<?php echo esc_attr($cf_zone); ?>" size="60"></td></tr>
        <tr><th>Cloudflare API Token</th><td><input type="text" name="gispro_cf_token" value="<?php echo esc_attr($cf_token); ?>" size="60"></td></tr>
        <tr><th>Retry count</th><td><input type="number" name="gispro_retry" value="<?php echo intval($retry); ?>" min="0" max="10"></td></tr>
        </table>
        <?php submit_button(); ?>
        </form>
        <h2>Bulk Sync</h2>
        <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
            <?php wp_nonce_field('gis_v15_final_bulk'); ?>
            <input type="hidden" name="action" value="gis_v15_final_bulk">
            <p><button class="button">Enqueue all uploads for GitHub sync</button></p>
        </form>
        <h2>Logs</h2>
        <?php $logs = get_option($this->logs,[]); if (!$logs) $logs=[]; ?>
        <table class="widefat"><thead><tr><th>Time</th><th>Type</th><th>Message</th></tr></thead><tbody>
        <?php foreach(array_slice(array_reverse($logs),0,200) as $l): ?>
            <tr><td><?php echo esc_html($l['time']); ?></td><td><?php echo esc_html($l['type']); ?></td><td><?php echo esc_html($l['msg']); ?></td></tr>
        <?php endforeach; ?>
        </tbody></table>
        </div>
        <?php
    }

    public function handle_admin_action(){
        if (!current_user_can('manage_options')) wp_die('no');
        if (isset($_POST['gis_action']) && $_POST['gis_action']=='bulk' && check_admin_referer('gis_v15_final_bulk')) {
            $this->enqueue_all_uploads();
            wp_redirect(admin_url('admin.php?page=gispro_v15_final'));
            exit;
        }
    }

    private function enqueue_all_uploads(){
        $up = wp_get_upload_dir();
        $base = $up['basedir'];
        $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($base));
        foreach ($it as $f) {
            if ($f->isFile()) {
                $rel = ltrim(str_replace($base,'',$f.getPathname()),'/\\');
                $this->enqueue('image-bed/'.$rel,$f.getPathname());
            }
        }
        $this->log('info','Enqueued all uploads');
    }

    private function enqueue($path,$file){
        $q = get_option($this->queue,[]);
        $q[]=['path'=>$path,'file'=>$file,'tries'=>0];
        update_option($this->queue,$q);
    }

    public function on_add_attachment($post_id){
        $file = get_attached_file($post_id);
        if (!$file || !file_exists($file)) return;
        $this->upload_and_enqueue_sizes($post_id,$file);
    }

    public function on_generate_metadata($metadata,$attachment_id){
        $file = get_attached_file($attachment_id);
        if ($file && file_exists($file)) {
            $this->upload_and_enqueue_sizes($attachment_id,$file);
        }
        return $metadata;
    }

    private function upload_and_enqueue_sizes($post_id,$file){
        $gpath = $this->map_path($file);
        if (!$this->github_put($gpath,$file)) $this->enqueue($gpath,$file); else $this->log('info',"Uploaded {$gpath}");
        $meta = wp_get_attachment_metadata($post_id);
        if (!empty($meta['sizes'])){
            foreach($meta['sizes'] as $s){
                $sizefile = $this->size_file_from_meta($file,$s);
                if (file_exists($sizefile)){
                    $srel = $this->map_path($sizefile);
                    if (!$this->github_put($srel,$sizefile)) $this->enqueue($srel,$sizefile); else $this->log('info',"Uploaded {$srel}");
                }
            }
        }
        $webp = preg_replace('/\\.[^.]+$/','.webp',$file);
        if (file_exists($webp)){
            $wrel = $this->map_path($webp);
            if (!$this->github_put($wrel,$webp)) $this->enqueue($wrel,$webp); else $this->log('info',"Uploaded {$wrel}");
        }
    }

    public function on_delete_attachment($post_id){
        $file = get_attached_file($post_id);
        if (!$file) return;
        $rel = $this->map_path($file);
        $this->github_delete($rel);
        $meta = wp_get_attachment_metadata($post_id);
        if (!empty($meta['sizes'])){
            foreach($meta['sizes'] as $s){
                $sf = $this->size_file_from_meta($file,$s);
                $this->github_delete($this->map_path($sf));
            }
        }
        $this->github_delete($this->map_path(preg_replace('/\\.[^.]+$/','.webp',$file)));
        $this->log('info',"Deleted remote for {$rel}");
    }

    public function filter_attachment_url($url,$post_id){
        $cdn = rtrim(get_option('gispro_cdn','https://img.facechangingworld.com'),'/');
        $file = get_attached_file($post_id);
        if (!$file) return $url;
        $up = wp_get_upload_dir();
        $basedir = $up['basedir'];
        $rel = ltrim(str_replace($basedir,'',$file),'/\\');
        return $cdn.'/image-bed/'.$rel;
    }

    public function attachment_fields_to_edit($form_fields,$post){
        $url = wp_get_attachment_url($post->ID);
        $form_fields['cdn_link'] = ['label'=>'CDN Link','input'=>'html','html'=>'<input readonly style="width:100%" value="'.esc_attr($url).'">'];
        return $form_fields;
    }

    public function media_columns($cols){
        $cols['gis_sync'] = 'GitHub';
        return $cols;
    }

    public function media_custom_column($column,$id){
        if ($column!='gis_sync') return;
        $info = $this->check_remote_for_attachment($id);
        if ($info===true) echo '<span style="color:green">✅</span>';
        elseif ($info==='pending') echo '<span style="color:orange">⏳</span>';
        else echo '<span style="color:red">❌</span>';
    }

    private function check_remote_for_attachment($id){
        $file = get_attached_file($id);
        if (!$file) return false;
        $rel = $this->map_path($file);
        $exists = $this->github_get($rel);
        if ($exists) return true;
        // check queue for pending
        $q = get_option($this->queue,[]);
        foreach($q as $item) if ($item['path']==$rel) return 'pending';
        return false;
    }

    private function map_path($file){
        $up = wp_get_upload_dir();
        $basedir = $up['basedir'];
        $rel = ltrim(str_replace($basedir,'',$file),'/\\');
        return 'image-bed/'.$rel;
    }

    private function size_file_from_meta($original_file,$size_meta){
        $pi = pathinfo($original_file);
        $file = $pi['dirname'].'/'.$pi['filename'].'-'.$size_meta['width'].'x'.$size_meta['height'].'.'.$pi['extension'];
        return $file;
    }

    public function process_queue(){
        $q = get_option($this->queue,[]);
        $opts = $this->opts();
        $new = [];
        foreach($q as $item){
            $ok = $this->github_put($item['path'],$item['file']);
            if ($ok) $this->log('info',"Retried {$item['path']}");
            else {
                $item['tries'] = $item['tries']+1;
                if ($item['tries'] < intval($opts['retry'])) $new[]=$item;
                else $this->log('error',"Give up {$item['path']}");
            }
        }
        update_option($this->queue,$new);
    }

    public function wpcli_sync($args,$assoc){ WP_CLI::log('Enqueueing all...'); $this->enqueue_all_uploads(); WP_CLI::success('Enqueued'); }

    private function opts(){ $o = get_option('gispro_v15_final_opts',[]); return wp_parse_args($o, ['repo'=>'facechangingworld/image-bed','branch'=>'main','cdn'=>'https://img.facechangingworld.com','retry'=>3]); }
    private function get_token(){ $o = get_option('gispro_token',''); if (!$o) return false; if (base64_decode($o,true)) return base64_decode($o); return $o; }

    private function github_get($path){
        $o = $this->opts(); $token = $this->get_token(); if (!$token) return false;
        $url = "https://api.github.com/repos/{$o['repo']}/contents/".rawurlencode($path)."?ref=".rawurlencode($o['branch']);
        $ch = curl_init();
        curl_setopt_array($ch,[CURLOPT_URL=>$url,CURLOPT_RETURNTRANSFER=>true,CURLOPT_HTTPHEADER=>["Authorization: token $token","User-Agent: GISPro"],CURLOPT_TIMEOUT=>20]);
        $res = curl_exec($ch); $code = curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch);
        if ($code==200) return json_decode($res,true); return false;
    }

    private function github_put($path,$localfile){
        $o = $this->opts(); $token = $this->get_token(); if (!$token) { $this->log('error','No token'); return false; }
        $api = "https://api.github.com/repos/{$o['repo']}/contents/".rawurlencode($path);
        $content = base64_encode(file_get_contents($localfile));
        $data = ['message'=>'Upload via GISPro','content'=>$content,'branch'=>$o['branch']];
        $exists = $this->github_get($path);
        if ($exists && isset($exists['sha'])) $data['sha'] = $exists['sha'];
        $ch = curl_init();
        curl_setopt_array($ch,[CURLOPT_URL=>$api,CURLOPT_RETURNTRANSFER=>true,CURLOPT_CUSTOMREQUEST=>'PUT',CURLOPT_POSTFIELDS=>json_encode($data),CURLOPT_HTTPHEADER=>["Authorization: token $token","User-Agent: GISPro","Content-Type: application/json"],CURLOPT_TIMEOUT=>40]);
        $res = curl_exec($ch); $code = curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch); return ($code==201||$code==200);
    }

    private function github_delete($path){
        $o = $this->opts(); $token = $this->get_token(); if (!$token) return false;
        $file = $this->github_get($path); if (!$file || empty($file['sha'])) return false;
        $api = "https://api.github.com/repos/{$o['repo']}/contents/".rawurlencode($path);
        $data = ['message'=>'Delete via GISPro','sha'=>$file['sha'],'branch'=>$o['branch']];
        $ch = curl_init();
        curl_setopt_array($ch,[CURLOPT_URL=>$api,CURLOPT_RETURNTRANSFER=>true,CURLOPT_CUSTOMREQUEST=>'DELETE',CURLOPT_POSTFIELDS=>json_encode($data),CURLOPT_HTTPHEADER=>["Authorization: token $token","User-Agent: GISPro","Content-Type: application/json"],CURLOPT_TIMEOUT=>20]);
        curl_exec($ch); curl_close($ch); return true;
    }

    private function log($type,$msg){ $l = get_option($this->logs,[]); $l[]=['time'=>current_time('mysql'),'type'=>$type,'msg'=>$msg]; if(count($l)>1000)$l=array_slice($l,-1000); update_option($this->logs,$l); }
}

$GLOBALS['gispro_v15_final'] = new GISPro_v15_Final();

add_action('admin_post_gis_v15_final_bulk', function(){ $g = $GLOBALS['gispro_v15_final']; $g->handle_admin_action(); });
add_action('admin_init', function(){ if (isset($_GET['reset']) && $_GET['reset']=='1' && current_user_can('manage_options')){ update_option('gispro_token',''); wp_redirect(admin_url('admin.php?page=gispro_v15_final')); exit; } });
?>