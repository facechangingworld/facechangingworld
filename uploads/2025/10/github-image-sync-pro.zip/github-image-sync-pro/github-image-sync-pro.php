<?php
/*
Plugin Name: GitHub Image Sync Pro
Description: Auto upload images to GitHub (uploads/... structure), WebP conversion, Cloudflare purge, retry queue, logs, editor replacement, batch replace, token masking and reset.
Version: 1.0
Author: FCW
*/

if (!defined('ABSPATH')) exit;

class GIS_Pro {
    private $opt_name = 'gis_pro_opts';
    private $logs = 'gis_pro_logs';
    private $queue = 'gis_pro_queue';

    public function __construct() {
        add_action('admin_menu', [$this, 'menu']);
        add_action('admin_init', [$this, 'register']);
        add_action('add_attachment', [$this, 'on_upload']);
        add_filter('wp_get_attachment_url', [$this, 'replace_url'], 999);
        add_action('content_save_pre', [$this, 'editor_replace']);
        add_action('the_content', [$this, 'the_content_replace']);
        add_action('admin_post_gis_reset_token', [$this, 'reset_token']);
        add_action('admin_post_gis_manual_sync', [$this, 'manual_sync']);
        add_action('admin_post_gis_batch_replace', [$this, 'batch_replace']);
        add_action('admin_post_gis_purge_url', [$this, 'purge_url_handler']);
        if (!wp_next_scheduled('gis_pro_retry')) wp_schedule_event(time(), 'hourly', 'gis_pro_retry');
        add_action('gis_pro_retry', [$this, 'process_queue']);
    }

    public function register() {
        register_setting($this->opt_name, $this->opt_name);
    }

    public function menu() {
        add_options_page('GitHub Image Sync Pro', 'GitHub Image Sync Pro', 'manage_options', 'gis-pro', [$this, 'page']);
    }

    private function opts() {
        $def = [
            'token'=>'',
            'repo'=>'facechangingworld/image-bed',
            'branch'=>'main',
            'cdn'=>'https://img.facechangingworld.com',
            'cf_zone'=>'',
            'cf_token'=>'',
            'enable_webp'=>1,
            'webp_q'=>80,
            'retry'=>3,
            'editor_replace'=>1
        ];
        $o = get_option($this->opt_name, []);
        return array_merge($def, is_array($o)?$o:[]);
    }

    public function page() {
        if (!current_user_can('manage_options')) return;
        $opts = $this->opts();
        if ($_POST && isset($_POST[$this->opt_name])) {
            check_admin_referer('gis_pro_save');
            $data = $_POST[$this->opt_name];
            // store token base64 encoded if provided
            if (!empty($data['token']) && $data['token'] !== '************') $data['token'] = base64_encode(trim($data['token']));
            else { $data['token'] = $opts['token']; } // keep existing if masked/blank
            update_option($this->opt_name, $data);
            echo '<div class="updated"><p>Saved.</p></div>';
            $opts = $this->opts();
        }
        $masked = !empty($opts['token']) ? '************' : '';
        ?>
        <div class="wrap">
        <h1>GitHub Image Sync Pro</h1>
        <form method="post" action="">
        <?php wp_nonce_field('gis_pro_save'); ?>
        <?php $name = $this->opt_name; $o = get_option($name); ?>
        <table class="form-table">
        <tr><th>GitHub Token</th>
            <td>
                <input id="gis_token_input" type="text" name="<?php echo $name; ?>[token]" value="<?php echo esc_attr($masked); ?>" size="60" <?php echo $masked ? 'disabled' : ''; ?>>
                <?php if ($masked): ?>
                    <a href="<?php echo esc_url(admin_url('admin-post.php?action=gis_reset_token')); ?>" class="button" onclick="return confirm('Reset token?')">Reset Token</a>
                <?php endif; ?>
                <p class="description">Token stored encoded. To change, click Reset Token then save a new token.</p>
            </td></tr>
        <tr><th>Repo (user/repo)</th><td><input type="text" name="<?php echo $name; ?>[repo]" value="<?php echo esc_attr($opts['repo']); ?>" size="40"></td></tr>
        <tr><th>Branch</th><td><input type="text" name="<?php echo $name; ?>[branch]" value="<?php echo esc_attr($opts['branch']); ?>" size="10"></td></tr>
        <tr><th>CDN Domain</th><td><input type="text" name="<?php echo $name; ?>[cdn]" value="<?php echo esc_attr($opts['cdn']); ?>" size="40"></td></tr>
        <tr><th>Cloudflare Zone ID</th><td><input type="text" name="<?php echo $name; ?>[cf_zone]" value="<?php echo esc_attr($opts['cf_zone']); ?>" size="40"></td></tr>
        <tr><th>Cloudflare API Token</th><td><input type="text" name="<?php echo $name; ?>[cf_token]" value="<?php echo esc_attr($opts['cf_token']); ?>" size="60"></td></tr>
        <tr><th>Enable WebP</th><td><input type="checkbox" name="<?php echo $name; ?>[enable_webp]" value="1" <?php checked(1, $opts['enable_webp']); ?>> Enable &nbsp; Quality: <input type="number" name="<?php echo $name; ?>[webp_q]" value="<?php echo intval($opts['webp_q']); ?>" min="10" max="100" style="width:70px"></td></tr>
        <tr><th>Retry count</th><td><input type="number" name="<?php echo $name; ?>[retry]" value="<?php echo intval($opts['retry']); ?>" min="0" max="10"></td></tr>
        <tr><th>Editor replace on save</th><td><input type="checkbox" name="<?php echo $name; ?>[editor_replace]" value="1" <?php checked(1, $opts['editor_replace']); ?>></td></tr>
        </table>
        <?php submit_button(); ?>
        </form>

        <h2>Manual Tools</h2>
        <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
            <?php wp_nonce_field('gis_manual_sync'); ?>
            <input type="hidden" name="action" value="gis_manual_sync">
            <p><button class="button">Manual sync queued items now</button></p>
        </form>

        <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
            <?php wp_nonce_field('gis_batch_replace'); ?>
            <input type="hidden" name="action" value="gis_batch_replace">
            <p><button class="button">Batch replace WP uploads to CDN in all posts</button></p>
        </form>

        <h3>Logs</h3>
        <?php $logs = get_option($this->logs, []); if (!$logs) $logs=[]; ?>
        <table class="widefat"><thead><tr><th>Time</th><th>Type</th><th>Msg</th></tr></thead><tbody>
        <?php foreach (array_slice(array_reverse($logs),0,200) as $l): ?>
            <tr><td><?php echo esc_html($l['time']); ?></td><td><?php echo esc_html($l['type']); ?></td><td><?php echo esc_html($l['msg']); ?></td></tr>
        <?php endforeach; ?>
        </tbody></table>

        </div>
        <script>
        // prevent masked token from being submitted; if masked, clear input so server keeps old token
        (function(){
            var form = document.querySelector('.wrap form');
            if (!form) return;
            form.addEventListener('submit', function(){
                var t = document.getElementById('gis_token_input');
                if (t && t.disabled) t.name = '';
            });
        })();
        </script>
        <?php
    }

    public function reset_token() {
        if (!current_user_can('manage_options')) wp_die('no');
        $opts = $this->opts();
        $opts['token'] = '';
        update_option($this->opt_name, $opts);
        wp_redirect(admin_url('options-general.php?page=gis-pro'));
        exit;
    }

    private function log($type,$msg){
        $l = get_option($this->logs, []);
        $l[] = ['time'=>current_time('mysql'),'type'=>$type,'msg'=>$msg];
        if(count($l)>500) $l=array_slice($l,-500);
        update_option($this->logs,$l);
    }

    public function on_upload($post_id){
        $file = get_attached_file($post_id);
        if(!$file || !file_exists($file)) return;
        $this->handle_file($file);
    }

    private function handle_file($file){
        $rel = $this->relpath($file);
        if($this->github_put($rel,$file)){
            $this->log('info',"Uploaded $rel");
            $opts = $this->opts();
            if(!empty($opts['cf_zone']) && !empty($opts['cf_token'])) $this->cf_purge(rtrim($opts['cdn'],'/').'/'.$rel);
        } else {
            $this->log('error',"Queue $rel");
            $this->enqueue($rel,$file);
        }
        $opts = $this->opts();
        if($opts['enable_webp']){
            $tmp = $this->make_webp($file,intval($opts['webp_q']));
            if($tmp){
                $webp_rel = preg_replace('/\.[^.]+$/','.webp',$rel);
                if($this->github_put($webp_rel,$tmp)){
                    $this->log('info',"Uploaded $webp_rel");
                    if(!empty($opts['cf_zone']) && !empty($opts['cf_token'])) $this->cf_purge(rtrim($opts['cdn'],'/').'/'.$webp_rel);
                } else {
                    $this->log('error',"Queue $webp_rel");
                    $this->enqueue($webp_rel,$tmp);
                }
                @unlink($tmp);
            } else $this->log('warn',"WebP failed for $rel");
        }
    }

    private function relpath($file){
        $up = wp_get_upload_dir();
        $basedir = $up['basedir'];
        $rel = ltrim(str_replace($basedir,'',$file),'/\\');
        return 'uploads/'.$rel;
    }

    private function github_put($path,$local){
        $opts = $this->opts();
        $repo=$opts['repo']; $branch=$opts['branch']; $token=$this->get_token();
        if(!$token){ $this->log('error','No token'); return false; }
        $api = "https://api.github.com/repos/$repo/contents/$path";
        $content = base64_encode(file_get_contents($local));
        $payload=['message'=>'Upload via GIS Pro','content'=>$content,'branch'=>$branch];
        $exists = $this->github_get($path);
        if($exists && isset($exists['sha'])) $payload['sha'] = $exists['sha'];
        $ch = curl_init();
        curl_setopt_array($ch,[CURLOPT_URL=>$api,CURLOPT_RETURNTRANSFER=>true,CURLOPT_CUSTOMREQUEST=>'PUT',CURLOPT_POSTFIELDS=>json_encode($payload),CURLOPT_HTTPHEADER=>["Authorization: token $token","User-Agent: GIS-Pro","Content-Type: application/json"],CURLOPT_TIMEOUT=>30]);
        $res = curl_exec($ch);
        $code = curl_getinfo($ch,CURLINFO_HTTP_CODE);
        curl_close($ch);
        return ($code==201||$code==200);
    }

    private function github_get($path){
        $opts = $this->opts();
        $repo=$opts['repo']; $branch=$opts['branch']; $token=$this->get_token();
        $url = "https://api.github.com/repos/$repo/contents/$path?ref=".rawurlencode($branch);
        $ch = curl_init();
        curl_setopt_array($ch,[CURLOPT_URL=>$url,CURLOPT_RETURNTRANSFER=>true,CURLOPT_HTTPHEADER=>["Authorization: token $token","User-Agent: GIS-Pro"],CURLOPT_TIMEOUT=>20]);
        $res = curl_exec($ch);
        $code = curl_getinfo($ch,CURLINFO_HTTP_CODE);
        curl_close($ch);
        if($code==200) return json_decode($res,true);
        return false;
    }

    private function get_token(){
        $opts=$this->opts();
        if(empty($opts['token'])) return false;
        $t = $opts['token'];
        if(base64_decode($t,true)) return base64_decode($t);
        return $t;
    }

    private function enqueue($path,$file){
        $q = get_option($this->queue,[]);
        $q[]=['path'=>$path,'file'=>$file,'tries'=>0];
        update_option($this->queue,$q);
    }

    public function process_queue(){
        $q = get_option($this->queue,[]);
        $opts = $this->opts();
        $new = [];
        foreach($q as $item){
            $ok = $this->github_put($item['path'],$item['file']);
            if($ok){
                $this->log('info',"Retry uploaded {$item['path']}");
                if(!empty($opts['cf_zone']) && !empty($opts['cf_token'])) $this->cf_purge(rtrim($opts['cdn'],'/').'/'.$item['path']);
            } else {
                $item['tries']=$item['tries']+1;
                if($item['tries']<intval($opts['retry'])) $new[]=$item;
                else $this->log('error',"Give up {$item['path']}");
            }
        }
        update_option($this->queue,$new);
    }

    public function manual_sync(){
        if(!current_user_can('manage_options')) wp_die('no');
        check_admin_referer('gis_manual_sync');
        $this->process_queue();
        wp_redirect(admin_url('options-general.php?page=gis-pro'));
        exit;
    }

    public function batch_replace(){
        if(!current_user_can('manage_options')) wp_die('no');
        check_admin_referer('gis_batch_replace');
        $opts=$this->opts();
        $local = content_url('uploads');
        $cdn = rtrim($opts['cdn'],'/').'/uploads';
        $args=['post_type'=>'post','posts_per_page'=>-1,'post_status'=>'any'];
        $ps = get_posts($args);
        foreach($ps as $p){
            $c = $p->post_content;
            if(strpos($c,$local)!==false){
                $nc = str_replace($local,$cdn,$c);
                wp_update_post(['ID'=>$p->ID,'post_content'=>$nc]);
                $this->log('info',"Replaced in post {$p->ID}");
            }
        }
        wp_redirect(admin_url('options-general.php?page=gis-pro'));
        exit;
    }

    public function purge_url_handler(){
        if(!current_user_can('manage_options')) wp_die('no');
        check_admin_referer('gis_purge_url');
        $url = isset($_POST['url'])?esc_url_raw($_POST['url']):'';
        if($url) $this->cf_purge($url);
        wp_redirect(admin_url('options-general.php?page=gis-pro'));
        exit;
    }

    private function cf_purge($url){
        $opts = $this->opts();
        if(empty($opts['cf_zone']) || empty($opts['cf_token'])) return false;
        $api = "https://api.cloudflare.com/client/v4/zones/".trim($opts['cf_zone'])."/purge_cache";
        $data = json_encode(['files'=>[$url]]);
        $ch = curl_init();
        curl_setopt_array($ch,[CURLOPT_URL=>$api,CURLOPT_RETURNTRANSFER=>true,CURLOPT_CUSTOMREQUEST=>'POST',CURLOPT_POSTFIELDS=>$data,CURLOPT_HTTPHEADER=>["Authorization: Bearer ".trim($opts['cf_token']),"Content-Type: application/json"],CURLOPT_TIMEOUT=>20]);
        $res = curl_exec($ch);
        $code = curl_getinfo($ch,CURLINFO_HTTP_CODE);
        curl_close($ch);
        $this->log('info',"CF purge {$url} => $code");
        return ($code==200);
    }

    private function make_webp($file,$q=80){
        if(extension_loaded('imagick')){
            try{
                $im = new Imagick($file);
                $im->setImageFormat('webp');
                $im->setImageCompressionQuality($q);
                $tmp = wp_tempnam($file).'.webp';
                $im->writeImage($tmp);
                $im->clear(); $im->destroy();
                if(file_exists($tmp)) return $tmp;
            }catch(Exception $e){}
        }
        if(function_exists('imagecreatefromstring') && function_exists('imagewebp')){
            $data = file_get_contents($file);
            $img = imagecreatefromstring($data);
            if(!$img) return false;
            $tmp = wp_tempnam($file).'.webp';
            imagewebp($img,$tmp,$q);
            imagedestroy($img);
            if(file_exists($tmp)) return $tmp;
        }
        return false;
    }

    public function editor_replace($content){
        $opts = $this->opts();
        if(empty($opts['editor_replace'])) return $content;
        $local = content_url('uploads');
        $cdn = rtrim($opts['cdn'],'/').'/uploads';
        return str_replace($local,$cdn,$content);
    }

    public function the_content_replace($content){
        $opts = $this->opts();
        $local = content_url('uploads');
        $cdn = rtrim($opts['cdn'],'/').'/uploads';
        return str_replace($local,$cdn,$content);
    }

    public function replace_url($url){
        if(is_admin()) return $url;
        $opts = $this->opts();
        $local = content_url('uploads');
        $cdn = rtrim($opts['cdn'],'/').'/uploads';
        return str_replace($local,$cdn,$url);
    }
}

new GIS_Pro();
?>