GitHub Image Sync Pro v1.3 - Placeholder build
This archive is a placeholder. Functional code will be delivered in subsequent update.